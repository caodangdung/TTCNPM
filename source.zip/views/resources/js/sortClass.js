$.ajax({
    url: "/"
})