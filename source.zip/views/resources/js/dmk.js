document.getElementById('Cpass').addEventListener('click',function(){
    event.preventDefault();
    window.open('/change-pass');
})